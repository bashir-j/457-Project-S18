const url = "http://192.168.1.114:3005/";

angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {
	console.log("entereeeed");

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
	  console.log("close");
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
	   console.log("open");
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})

.controller('PlaylistsCtrl', function($scope) {
  $scope.playlists = [
    { title: 'Reggae', id: 1 },
    { title: 'Chill', id: 2 },
    { title: 'Dubstep', id: 3 },
    { title: 'Indie', id: 4 },
    { title: 'Rap', id: 5 },
    { title: 'Cowbell', id: 6 }
  ];
})


.controller('MenuCtrl', function($scope, $stateParams, $window, $http, $rootScope, $ionicPlatform, $cordovaBeacon) {
	$scope.history = function(){

    $scope.userHistory = [];
    $http.post(url + "get_user_history", {"uid": $window.localStorage.getItem("uid")}).then(function(data){
		console.log(data);
      console.log(data.data);
      if (data.data == "session_timeout")
      {
         $window.location.assign("#/login");
      }
      else {
        angular.forEach(data.data, function( value , key) {
          console.log(value);
          $scope.userHistory.push({
            "beacon_id": value.beacon_id,
            "beacon_data": value.beacon_data
          });
      });
      }
      });
		}
		
	$scope.request = function()
  {
	  var client = $rootScope.MQTTClient;
      client.onMessageArrived = function (message) {
		  console.log("message");
        message = JSON.parse(message.payloadString);
        $scope.update_data = message.paintings;
        $scope.$apply();
      };
  }	
  
	$rootScope.$on('logged',function(event,args){
	  $scope.request();
	});
		
		
	$scope.logout = function()
	{
		console.log($window.localStorage.getItem("uid"));
		$window.localStorage.removeItem("uid");
		$window.location.assign('#/login');
	}
	
		$scope.piece_Click = function(data)
  { 
    $scope.clickedImg = url +  data.image;
    $scope.clickedDesc = data.description;
    $http.post(url + "push_into_history", {"uid": $window.localStorage.getItem("uid"), "art_piece": data.art_piece, "description": data.description});
  }
  
	$rootScope.$on("logged",function(event,args){
		console.log("immahere");
        $cordovaBeacon.requestWhenInUseAuthorization();

        $rootScope.$on("$cordovaBeacon:didRangeBeaconsInRegion", function(event, pluginResult) {
			console.log("immahereder");
            for(var i = 0; i < pluginResult.beacons.length; i++) {
				if ($scope.uniqueBeaconKey  !=  (pluginResult.beacons[i].major + pluginResult.beacons[i].minor) && pluginResult.beacons[i].proximity == "ProximityImmediate"){
					console.log($scope.uniqueBeaconKey);
					console.log(pluginResult.beacons[i].major + pluginResult.beacons[i].minor);
					$scope.uniqueBeaconKey = pluginResult.beacons[i].major + pluginResult.beacons[i].minor;
					$scope.$apply();
					var uid = $window.localStorage.getItem("uid");
					var client = $rootScope.MQTTClient;
					console.log("issaclient");
					console.log(client);
				  message = new Paho.MQTT.Message(JSON.stringify({"uid": $window.localStorage.getItem("uid"), "beacon_id": $scope.uniqueBeaconKey}));
				  message.destinationName = "server/myserver";
				  client.send(message);
				}
            }
        });

        $cordovaBeacon.startRangingBeaconsInRegion($cordovaBeacon.createBeaconRegion("estimote", "b9407f30-f5f8-466e-aff9-25556b57fe6d"));

    });

})
.controller('LoginCtrl', function($scope, $http, $window, $rootScope) {
	$scope.toSend = {};
  $scope.submit = function () {
      if (!$scope.toSend.uname || !$scope.toSend.psw) {
          alert("Please enter both the username and password to login!");
      }
      // AJAX code to submit form
      else {
      $http.post(url + 'login_router',$scope.toSend)
      .then(function(data) {
     if (data.data == "invalid_uname"){
        if (window.confirm('It looks like we do not have a user under this account name!\nPlease sign up to use this website.\nClick "ok" to be redirected.')) 
        {
          $window.location.assign('#/signup');
        }
        }
        else if (data.data == "invalid_password"){
          alert("The username and password combination is incorrect! Please try again.");
        }
        else if (data.data.status == "authok"){
          $window.localStorage.setItem("uid", data.data.uid);
		  	console.log("nsdklsd");
			var wsbroker = "broker.hivemq.com"; 
			var wsport = 8000;
			var client = new Paho.MQTT.Client(wsbroker, wsport,"myclientid_" + parseInt(Math.random() * 100, 10));
			$rootScope.MQTTClient = client;
			var uid = $window.localStorage.getItem("uid");
			console.log(uid);
      var options = {timeout: 3,onSuccess: function () {

        console.log("mqtt connected");
        client.subscribe(uid, {qos: 1});
		$rootScope.$emit('logged',{});
      },
      onFailure: function (message) {console.log("Connection failed: " + message.erorMessage);}};

		client.connect(options);
		$window.location.assign('#/menu/request');
        }
      });
  }

}
})
.controller('SignUpCtrl', function($scope, $http, $window) {
	$scope.toSend = {};
	  $scope.submit = function () {

      if (!$scope.toSend.uname || !$scope.toSend.psw) {
          alert("Please enter both the username and password to signup!");
      }
      // AJAX code to submit form
      else {
      $http.post(url +'signup_router',$scope.toSend)
      .then(function(data) {
      console.log(data.data);
        if (data.data == "invalid_uname")
        {
          alert('It looks like we already have a user under this account name!\nPlease try signing up with another username to use this website.');
        }
        else 
        {
          alert('Thank you for signing up to our website! Please login to your account.');
			$window.location.assign('#/login');
        }
      });
  }
}
});

